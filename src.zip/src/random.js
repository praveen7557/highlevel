$(function () {
  $('.selectpicker').selectpicker();
})();